package com.core.entities;

public enum Plan {
	MONTHLY, QUARTERLY, YEARLY;
}

//	STANDARD(7500), PRO(10000), BUYER_STANDARD(2500), BUYER_PRO(5000), SELLER_STANDARD(5000), SELLER_PRO(7500);
//
//	private final double price;
//
//	Plan(double price) {
//		this.price = price;
//	}
//
//	public double getDisplayName() {
//		return price;
//	}
//}
