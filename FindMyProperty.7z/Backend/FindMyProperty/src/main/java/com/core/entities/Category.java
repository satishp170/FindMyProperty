package com.core.entities;

public enum Category {
	VILLA, PLOT, ONE_BHK, TWO_BHK, THREE_BHK, FOUR_BHK, WAREHOUSE;

//	VILLA("Villa"), PLOT("Plot"), ONE_BHK("1 BHK"), TWO_BHK("2 BHK"), THREE_BHK("3 BHK"), FOUR_BHK("4 BHK"),
//	WAREHOUSE("Warehouse");
//
//	private final String displayName;
//
//	Category(String displayName) {
//		this.displayName = displayName;
//	}
//
//	public String getDisplayName() {
//		return displayName;
//	}
}
