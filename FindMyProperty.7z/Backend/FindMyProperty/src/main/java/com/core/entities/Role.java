package com.core.entities;

public enum Role {
	ADMIN, SELLER, BUYER, TRADER, GUEST;
}