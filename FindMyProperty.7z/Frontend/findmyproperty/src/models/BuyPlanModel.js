export class BuyPlanModel {
    constructor({
        id,
        role,
        plan
    }) {
        this.id = id;
        this.role = role;
        this.plan = plan;
    }
}
