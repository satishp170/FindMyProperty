export class Address {
    constructor({ lineOne, lineTwo, city, state, zipCode }) {
        this.lineOne = lineOne;
        this.lineTwo = lineTwo;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
    }
}